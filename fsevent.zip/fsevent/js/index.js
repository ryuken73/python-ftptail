const {dialog} = require('electron').remote

var fs = require('fs');

var inputDir = d3.select('#inputDir');

d3.select('#btnDirSelect').on('click', function(){
    var dirSelected = dialog.showOpenDialog({
        properties:['openDirectory']
    });
    inputDir.property('value', dirSelected);
    
})

d3.select('#btnStartWatch').on('click', function(){
    var watchDir = inputDir.property('value');
    var watchOpts = {recursive:true};
    dialog.showMessageBox({message:"Start Watch : " + watchDir});
    global.watcher = fs.watch(watchDir, watchOpts, onChange);

})

var onChange = function(evt,fname){
        var date = new Date();
        var timestamp = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
        console.log('%s : %s : %s', timestamp, evt, fname);
        var data = [timestamp, evt, fname];
        var tbody = d3.select('tbody');
        tbody.append('tr')
        .selectAll('td')
        .data(data)
        .enter()
        .append('td')
        .text(function(d){
            return d;
        });
}

d3.select('#btnStopWatch').on('click', function(){
    var watchDir = inputDir.property('value');
    global.watcher.close();
    dialog.showMessageBox({message:"Stop Watch : " + watchDir});
    
})
